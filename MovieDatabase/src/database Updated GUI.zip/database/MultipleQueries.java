package database;

/**
 * Creating different queries, JOIN, AND, OR, LIKE from multiple tables.
 * 
 * @authors Jonas Knochelmann, Shel Wah, and Irelan Bailey
 */
public class MultipleQueries {

	/**
	 * PrintS the Movie Name, Publication Year, and Country from Movie and Ip tables
	 * where country is America.
	 * 
	 * @return the value from Move and Ip tables.
	 */
	public static String Publication() {
		return "SELECT m.MovieName, m.PublicationYear, i.Country " 
				+ "FROM Movie m, Ip i "
				+ "WHERE m.MovieName = i.MovieName " 
				+ "AND Country = 'America' ";
	}

	/**
	 * Using query LIKE to return data if tables contain specific word lines.
	 * 
	 * @return the value where language is Korean and Director is 'Rod'.
	 */
	public static String OrQuery() {
		return "SELECT ID, Director " 
				+ "FROM Film " 
				+ "WHERE Language = 'Korean' " 
				+ "OR Director LIKE '%Rod%' ";
	}
	
	public static String Sorting() {
		return "SELECT * "
				+ "FROM IP"
				+ " ORDER BY Top DESC ";
		
	}
}
